/*
 * Rico Sandoval
 * CS 240
 * Assignment 1
 * Honor Pledge: I have neither given nor received unauthorized aid in completing this work, nor have I presented someone
	else's work as my own
 */




import java.util.Scanner;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import javax.imageio.ImageIO;

public class CS240Assignment1RicoSandoval
{

	/*
	 * The below method converts a Color object to a string representation based on its RGB values.
	 * It was written by the professor, Dominic Dabish, though he gave permission to use it in this assignment.
	 * It contributes to the third part of the assignment.
	 */
	public static String convert(Color color)
	{
		int red = color.getRed();
		int green = color.getGreen();
		int blue = color.getBlue();
		if (red == 237 && green == 28 && blue == 36)
		{
			return "R";
		}
		else if (red == 0 && green == 0 && blue == 0)
		{
			return "B";
		}
		else if (red == 255 && green == 242 && blue == 0)
		{
			return "Y";
		}
		else
		{
			return "(" + red + ", " + green + ", " + blue + ")";
		}
	}
	
	public static void main(String[] args) throws IOException
	{
		/*
		 * The below code reads the image file "smiley.png" and converts each pixel's color to a string representation.
		 * The converted color values are then written to a text file called "output.txt".
		 * This was written by the professor, Dominic Dabish, though he gave permission to use it in this assignment.
		 * It satisfies the third part of the assignment.
		 */
		PrintWriter outputFile = new PrintWriter("output.txt");
		BufferedImage imageFile = ImageIO.read(new File("./smiley.png"));
		int width = imageFile.getWidth();
		int height = imageFile.getHeight();
		for (int y = 0; y < height; y++)
		{
			for (int x = 0; x < width; x++)
			{
				Color color = new Color(imageFile.getRGB(x, y));
				String convertedColor = convert(color);
				outputFile.print(convertedColor);
				outputFile.print(" ");
			}
			outputFile.println();
		}
		outputFile.close();
		
		/*
		 * The below code prints the ASCII values of each character in the string "Rico." 
		 * It satisfies the first part of the assignment. It was written by the professor, Dominic Dabish,
		 * though he gave permission to use it in this assignment.
		 * My only change was changing the string from "Dominic" to "Rico."
		 */
		String s = "Rico";
		for (Character c : s.toCharArray())
		{
			System.out.println((int) c);
		}
		
		/*
		 * The below code prompts the user to enter an integer in decimal base,
		 * and then prints the equivalent values in binary, octal, and hexadecimal bases.
		 * This code was written by me, Rico Sandoval, and satisfies the second part of the assignment.
		 */
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter an integer in decimal base: ");
		if (!keyboard.hasNextInt())
		{
			System.out.println("You did not enter a valid integer.");
			keyboard.close();
		}
		else
		{
			int number = keyboard.nextInt();
			printNumber(number);
			keyboard.close();
		}
		
		
		
	}
	
	/*
	 * The below method prints the equivalent values of a given integer in binary,
	 * octal, decimal, and hexadecimal bases. It calls several methods that
	 * will convert the integer to the respective bases. This method was written by me, Rico Sandoval.
	 */
	public static void printNumber(int number)
	{

		System.out.println("The number you entered is "
				+ convertToBinary(number) + " in binary.");
		System.out.println("The number you entered is " + convertToOctal(number)
				+ " in octal.");
		System.out.println(
				"The number you entered is " + number + " in decimal.");
		System.out.println("The number you entered is "
				+ convertToHexadecimal(number) + " in hexadecimal.");

	}
	
	/*
	 * The below method converts a given integer to its equivalent value in the written base.
	 * These methods were written by me, Rico Sandoval.
	 */
	public static String convertToBinary(int number)
	{
		return Integer.toBinaryString(number);
	}
	
	public static String convertToOctal(int number)
	{
		return Integer.toOctalString(number);
	}
	
	public static String convertToHexadecimal(int number)
	{
		return Integer.toHexString(number);
	}

}
