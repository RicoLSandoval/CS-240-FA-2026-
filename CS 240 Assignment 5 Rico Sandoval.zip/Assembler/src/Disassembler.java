import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/*
 * Toy MIPS disassembler for the MHC files produced by Assembler.java.
 * Java 8+.
 *
 * Compile: javac Disassembler.java
 * Run:     java Disassembler fizzbuzz.mhc-ascii
 *       or java Disassembler fizzbuzz.mhc-bin
 *
 * Output:
 * - Writes <name>-reconstructed.asm beside the input file.
 *
 * Supported input formats:
 * - MHC-ASCII 1: text header, .text as 32-bit 0/1 lines, .data as 8-bit lines.
 * - MHC-BIN MHC1: 20-byte big-endian header, followed by raw .text then .data.
 *
 * Supported decoded instructions are exactly the real instructions used by the
 * companion assembler/FizzBuzz program: addi, addiu, addu, ori, lui, div,
 * mfhi, sll, beq, bne, j, jal, jr, lw, sw, syscall.
 *
 * Labels are regenerated as L_<8-hex-digit-address>. Pseudoinstructions and
 * original label names/comments are intentionally not recovered.
 * Data is reconstructed as .asciiz strings, which is sufficient for the
 * FizzBuzz data used by this assignment.
 */
public class Disassembler {
    static final int EXPECTED_TEXT_BASE = 0x00400000;
    static final int EXPECTED_DATA_BASE = 0x10010000;

    private static final String[] REGISTER_NAMES = {
        "zero", "at", "v0", "v1", "a0", "a1", "a2", "a3",
        "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
        "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
        "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra"
    };

    static class Image {
        final int textBase, dataBase;
        final byte[] text, data;
        Image(int textBase, int dataBase, byte[] text, byte[] data) {
            this.textBase = textBase;
            this.dataBase = dataBase;
            this.text = text;
            this.data = data;
        }
    }

    public static void main(String[] args) {
        try {
            if (args.length != 1) {
                System.out.println("Usage: java Disassembler <file.mhc-ascii|file.mhc-bin>");
                return;
            }

            Path input = Paths.get(args[0]);
            if (!Files.isRegularFile(input)) {
                System.out.println("Disassembly failed: file not found: " + input);
                return;
            }

            String lower = input.getFileName().toString().toLowerCase();
            Image image;
            if (lower.endsWith(".mhc-ascii")) {
                image = readAscii(input);
            } else if (lower.endsWith(".mhc-bin")) {
                image = readBinary(input);
            } else {
                throw new IllegalArgumentException("Input must end in .mhc-ascii or .mhc-bin");
            }

            String asm = disassemble(image);
            String name = input.getFileName().toString();
            String base = name.substring(0, name.lastIndexOf(".mhc-"));
            Path output = input.toAbsolutePath().getParent().resolve(base + "-reconstructed.asm");
            Files.write(output, asm.getBytes(StandardCharsets.UTF_8));

            System.out.println("Disassembly successful.");
            System.out.println("Created: " + output);
        } catch (IOException e) {
            System.out.println("Disassembly failed: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Disassembly failed: " + e.getMessage());
        }
    }

    static Image readBinary(Path path) throws IOException {
        byte[] bytes = Files.readAllBytes(path);
        if (bytes.length < 20) fail("Binary file is too short for an MHC1 header.");
        if (bytes[0] != 'M' || bytes[1] != 'H' || bytes[2] != 'C' || bytes[3] != '1') {
            fail("Invalid binary magic; expected MHC1.");
        }
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN);
        b.position(4);
        int textBase = b.getInt();
        int dataBase = b.getInt();
        int textBytes = b.getInt();
        int dataBytes = b.getInt();
        validateHeader(textBase, dataBase, textBytes, dataBytes);
        if (20L + textBytes + dataBytes != bytes.length) {
            fail("Binary length does not match header byte counts.");
        }
        byte[] text = new byte[textBytes];
        byte[] data = new byte[dataBytes];
        b.get(text);
        b.get(data);
        return new Image(textBase, dataBase, text, data);
    }

    static Image readAscii(Path path) throws IOException {
        List<String> lines = Files.readAllLines(path, StandardCharsets.US_ASCII);
        if (lines.isEmpty() || !lines.get(0).trim().equals("# MHC-ASCII 1")) {
            fail("Invalid ASCII header; expected # MHC-ASCII 1.");
        }

        Map<String, Integer> header = new HashMap<>();
        List<Byte> text = new ArrayList<>();
        List<Byte> data = new ArrayList<>();
        int section = 0;

        for (int i = 1; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty()) continue;
            if (line.equals("# BYTE_ORDER BIG-ENDIAN")) continue;
            if (line.startsWith("# TEXT_BASE ")) { header.put("TEXT_BASE", bitsToInt(line.substring(12), 32)); continue; }
            if (line.startsWith("# DATA_BASE ")) { header.put("DATA_BASE", bitsToInt(line.substring(12), 32)); continue; }
            if (line.startsWith("# TEXT_BYTES ")) { header.put("TEXT_BYTES", bitsToInt(line.substring(13), 32)); continue; }
            if (line.startsWith("# DATA_BYTES ")) { header.put("DATA_BYTES", bitsToInt(line.substring(13), 32)); continue; }
            if (line.startsWith("#")) fail("Unknown ASCII header line " + (i + 1) + ": " + line);
            if (line.equals(".text")) { section = 1; continue; }
            if (line.equals(".data")) { section = 2; continue; }

            if (section == 1) {
                int word = bitsToInt(line, 32);
                text.add((byte)(word >>> 24));
                text.add((byte)(word >>> 16));
                text.add((byte)(word >>> 8));
                text.add((byte)word);
            } else if (section == 2) {
                data.add((byte)bitsToInt(line, 8));
            } else {
                fail("Data encountered before .text/.data marker on line " + (i + 1));
            }
        }

        if (!header.containsKey("TEXT_BASE") || !header.containsKey("DATA_BASE") ||
            !header.containsKey("TEXT_BYTES") || !header.containsKey("DATA_BYTES")) {
            fail("ASCII header is missing required fields.");
        }
        byte[] textBytes = toArray(text);
        byte[] dataBytes = toArray(data);
        validateHeader(header.get("TEXT_BASE"), header.get("DATA_BASE"),
                       header.get("TEXT_BYTES"), header.get("DATA_BYTES"));
        if (textBytes.length != header.get("TEXT_BYTES") || dataBytes.length != header.get("DATA_BYTES")) {
            fail("ASCII payload byte counts do not match the header.");
        }
        return new Image(header.get("TEXT_BASE"), header.get("DATA_BASE"), textBytes, dataBytes);
    }

    static String disassemble(Image image) {
        if (image.text.length % 4 != 0) fail(".text byte count is not a multiple of 4.");

        int count = image.text.length / 4;
        int[] words = new int[count];
        TreeMap<Integer, String> labels = new TreeMap<>();
        for (int i = 0; i < count; i++) {
            int p = i * 4;
            words[i] = ((image.text[p] & 255) << 24) | ((image.text[p + 1] & 255) << 16)
                     | ((image.text[p + 2] & 255) << 8) | (image.text[p + 3] & 255);
            collectTarget(words[i], image.textBase + p, image, labels);
        }

        StringBuilder out = new StringBuilder();
        out.append(".data\n");
        appendData(out, image.data);
        out.append("\n.text\n.globl main\nmain:\n");

        for (int i = 0; i < count; i++) {
            int address = image.textBase + i * 4;
            if (i != 0 && labels.containsKey(address)) {
                out.append(labels.get(address)).append(":\n");
            }
            out.append("    ").append(decode(words[i], address, labels)).append('\n');
        }
        return out.toString();
    }

    static void collectTarget(int word, int address, Image image, Map<Integer, String> labels) {
        int opcode = word >>> 26;
        Integer target = null;
        if (opcode == 4 || opcode == 5) {
            int imm = (short)(word & 0xFFFF);
            target = address + 4 + imm * 4;
        } else if (opcode == 2 || opcode == 3) {
            target = ((address + 4) & 0xF0000000) | ((word & 0x03FFFFFF) << 2);
        }
        if (target != null) {
            if (target < image.textBase || target >= image.textBase + image.text.length || ((target - image.textBase) & 3) != 0) {
                fail(String.format("Control-flow target 0x%08X is outside .text.", target));
            }
            if (target != image.textBase) labels.put(target, labelName(target));
        }
    }

    static String decode(int word, int address, Map<Integer, String> labels) {
        int opcode = word >>> 26;
        int rs = (word >>> 21) & 31;
        int rt = (word >>> 16) & 31;
        int rd = (word >>> 11) & 31;
        int shamt = (word >>> 6) & 31;
        int funct = word & 63;
        int uimm = word & 0xFFFF;
        int simm = (short)uimm;

        switch (opcode) {
            case 0:
                if (word == 0x0000000C) return "syscall";
                switch (funct) {
                    case 0x21: return "addu " + reg(rd) + ", " + reg(rs) + ", " + reg(rt);
                    case 0x1A: return "div " + reg(rs) + ", " + reg(rt);
                    case 0x10: return "mfhi " + reg(rd);
                    case 0x00: return "sll " + reg(rd) + ", " + reg(rt) + ", " + shamt;
                    case 0x08: return "jr " + reg(rs);
                    default: failHex("Unsupported R-type funct", word);
                }
                break;
            case 8:  return "addi " + reg(rt) + ", " + reg(rs) + ", " + simm;
            case 9:  return "addiu " + reg(rt) + ", " + reg(rs) + ", " + simm;
            case 13: return "ori " + reg(rt) + ", " + reg(rs) + ", " + uimm;
            case 15: return "lui " + reg(rt) + ", " + uimm;
            case 4:
            case 5: {
                int target = address + 4 + simm * 4;
                return (opcode == 4 ? "beq " : "bne ") + reg(rs) + ", " + reg(rt) + ", " + targetLabel(target, labels);
            }
            case 2:
            case 3: {
                int target = ((address + 4) & 0xF0000000) | ((word & 0x03FFFFFF) << 2);
                return (opcode == 2 ? "j " : "jal ") + targetLabel(target, labels);
            }
            case 35: return "lw " + reg(rt) + ", " + simm + "(" + reg(rs) + ")";
            case 43: return "sw " + reg(rt) + ", " + simm + "(" + reg(rs) + ")";
            default: failHex("Unsupported opcode", word);
        }
        throw new IllegalArgumentException("Unreachable decode error.");
    }

    static void appendData(StringBuilder out, byte[] data) {
        int i = 0;
        while (i < data.length) {
            StringBuilder s = new StringBuilder();
            int start = i;
            while (i < data.length && data[i] != 0) {
                int b = data[i] & 255;
                if (b < 32 || b > 126) {
                    fail("Unsupported .data byte at offset " + i + ": only printable ASCII .asciiz data can be reconstructed.");
                }
                char c = (char)b;
                if (c == '\\' || c == '"') s.append('\\');
                s.append(c);
                i++;
            }
            if (i >= data.length) {
                fail("Unsupported .data layout starting at offset " + start + ": expected NUL-terminated .asciiz string.");
            }
            out.append("    .asciiz \"").append(s).append("\"\n");
            i++; // NUL
        }
    }

    static void validateHeader(int textBase, int dataBase, int textBytes, int dataBytes) {
        if (textBase != EXPECTED_TEXT_BASE) fail(String.format("Unsupported text base 0x%08X.", textBase));
        if (dataBase != EXPECTED_DATA_BASE) fail(String.format("Unsupported data base 0x%08X.", dataBase));
        if (textBytes < 0 || dataBytes < 0) fail("Negative segment byte count in header.");
        if ((textBytes & 3) != 0) fail("TEXT_BYTES must be a multiple of 4.");
    }

    static int bitsToInt(String bits, int expected) {
        bits = bits.trim();
        if (bits.length() != expected || !bits.matches("[01]+")) {
            fail("Expected exactly " + expected + " binary digits, got: " + bits);
        }
        long value = Long.parseLong(bits, 2);
        return (int)value;
    }

    static byte[] toArray(List<Byte> list) {
        byte[] result = new byte[list.size()];
        for (int i = 0; i < result.length; i++) result[i] = list.get(i);
        return result;
    }

    static String reg(int n) { return "$" + REGISTER_NAMES[n]; }
    static String labelName(int address) { return String.format("L_%08X", address); }
    static String targetLabel(int target, Map<Integer, String> labels) {
        String label = labels.get(target);
        if (label == null && target == EXPECTED_TEXT_BASE) return "main";
        if (label == null) fail(String.format("Missing generated label for 0x%08X.", target));
        return label;
    }
    static void failHex(String message, int word) { fail(String.format("%s: 0x%08X", message, word)); }
    static void fail(String message) { throw new IllegalArgumentException(message); }
}
